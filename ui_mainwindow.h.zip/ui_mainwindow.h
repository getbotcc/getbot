/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QLabel *status;
    QPushButton *pushGo;
    QProgressBar *progressBar;
    QPushButton *pushDownload;
    QLabel *labelVersion;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(475, 208);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setMinimumSize(QSize(475, 208));
        MainWindow->setMaximumSize(QSize(475, 208));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        sizePolicy.setHeightForWidth(centralWidget->sizePolicy().hasHeightForWidth());
        centralWidget->setSizePolicy(sizePolicy);
        stackedWidget = new QStackedWidget(centralWidget);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        stackedWidget->setGeometry(QRect(40, 20, 411, 171));
        stackedWidget->setFocusPolicy(Qt::NoFocus);
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        status = new QLabel(page);
        status->setObjectName(QStringLiteral("status"));
        status->setGeometry(QRect(20, 89, 351, 31));
        pushGo = new QPushButton(page);
        pushGo->setObjectName(QStringLiteral("pushGo"));
        pushGo->setGeometry(QRect(20, 130, 100, 27));
        pushGo->setFocusPolicy(Qt::ClickFocus);
        progressBar = new QProgressBar(page);
        progressBar->setObjectName(QStringLiteral("progressBar"));
        progressBar->setGeometry(QRect(20, 10, 351, 23));
        progressBar->setValue(0);
        pushDownload = new QPushButton(page);
        pushDownload->setObjectName(QStringLiteral("pushDownload"));
        pushDownload->setEnabled(false);
        pushDownload->setGeometry(QRect(270, 130, 100, 27));
        pushDownload->setCheckable(false);
        labelVersion = new QLabel(page);
        labelVersion->setObjectName(QStringLiteral("labelVersion"));
        labelVersion->setGeometry(QRect(20, 50, 351, 31));
        stackedWidget->addWidget(page);
        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        status->setText(QApplication::translate("MainWindow", "Make sure that bot is not running now", Q_NULLPTR));
        pushGo->setText(QApplication::translate("MainWindow", "Check ver.", Q_NULLPTR));
        pushDownload->setText(QApplication::translate("MainWindow", "Download", Q_NULLPTR));
        labelVersion->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
